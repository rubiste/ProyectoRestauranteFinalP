package com.example.comandaspt1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.SearchView;

import com.example.comandaspt1.Model.Data.Comanda;
import com.example.comandaspt1.Model.Data.Producto;
import com.example.comandaspt1.View.ComandasAdapter;
import com.example.comandaspt1.View.MainViewModel;
import com.example.comandaspt1.View.MesaAdapter;

import java.util.List;

public class Facturas extends AppCompatActivity {

    public static MainViewModel viewModel;
    private ComandasAdapter adapter;

    private ImageButton btImpresion;
    private Button btAdd;
    private SearchView svComandas;
    private View fragment;

    public static final String IDFACTURA = "idFactura";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_facturas);
        init();
    }

    private void init() {
        SharedPreferences sharedPreferences = getSharedPreferences(Conexion.TAG, Context.MODE_PRIVATE);
        final long idFactura = sharedPreferences.getLong(IDFACTURA, 0);

        fragment = findViewById(R.id.fFacturas);

        btAdd = findViewById(R.id.btAdd);
        btAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Facturas.this, Categorias.class);
                startActivity(intent);
            }
        });

        adapter = new ComandasAdapter(this);
        viewModel =  ViewModelProviders.of(this).get(MainViewModel.class);
        viewModel.getLiveDataProductosList().observe(this, new Observer<List<Producto>>() {
            @Override
            public void onChanged(List<Producto> productos) {
                adapter.setProductos(productos);
                cogerComandas();
            }
        });


        btImpresion = findViewById(R.id.btImpresion);
        btImpresion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Facturas.this, MainImpresion.class);
                intent.putExtra(IDFACTURA, idFactura);
                startActivity(intent);
            }
        });
    }

    private void cogerComandas() {
        viewModel.getLiveComandaList().observe(this, new Observer<List<Comanda>>() {
            @Override
            public void onChanged(List<Comanda> comandas) {
                adapter.setData(comandas);
                rellenarRecycler();
            }
        });
    }

    private void rellenarRecycler() {
        RecyclerView rvList = findViewById(R.id.rvList);
        rvList.setLayoutManager(new LinearLayoutManager(this));
        rvList.setAdapter(adapter);
        initSearch();
    }

    private void initSearch() {
        svComandas = findViewById(R.id.svComandas);
        svComandas.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return false;
            }
        });

        fragment.setVisibility(View.INVISIBLE);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_mesas, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_logout) {
            SharedPreferences sharedPreferences = getSharedPreferences(Conexion.TAG, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putLong(MainActivity.EMPLEADOREMEMBER, 0);
            editor.putInt(MainActivity.GERENTEREMEMBER, 0);
            editor.putInt(MesaAdapter.IDFACTURA, 0);
            editor.commit();
            Intent i = new Intent(Facturas.this, MainActivity.class);
            startActivity(i);
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        SharedPreferences sharedPreferences = getSharedPreferences(Conexion.TAG, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putLong(IDFACTURA, 0);
        editor.commit();
        Intent intent = new Intent(this, MesasLocal.class);
        startActivity(intent);
        finish();
    }
}
