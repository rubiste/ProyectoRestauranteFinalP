package com.example.comandaspt1.Contract;

public interface OnRestListenerFoto {

    void onSuccess(String message);
    void onFailure(String message);
}
