package com.example.comandaspt1.Contract;

public interface OnRestListener {

    void onSuccess(long id);
    void onFailure(String message);
}
